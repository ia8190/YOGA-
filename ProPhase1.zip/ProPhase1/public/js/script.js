document.addEventListener("DOMContentLoaded", function() {
    const form = document.querySelector(".newsletter form");
    const nameInput = form.querySelector('input[name="name"]');
    const emailInput = form.querySelector('input[name="email"]');
    const subscribeButton = form.querySelector('button[type="submit"]');
    const popup = document.getElementById("popup");

    form.addEventListener("submit", function(event) {
        event.preventDefault(); 
        const name = nameInput.value;
        const email = emailInput.value;

        if (name.trim() !== "" && email.trim() !== "") {
            popup.style.display = "block";
        } else {
            alert("Please enter both your name and email.");
        }

        nameInput.value = "";
        emailInput.value = "";
    });
    const closePopupButton = document.getElementById("close-popup");
    closePopupButton.addEventListener("click", function() {
        popup.style.display = "none";
    });
});


const testimonials = document.querySelectorAll('.testimonial');
let currenttest = 0;

function showTestimonial(index) {
    testimonials.forEach((testimonial, i) => {
        if (i === index) {
            testimonial.style.display = 'block';
        } else {
            testimonial.style.display = 'none';
        }
    });
}

showTestimonial(currenttest);
document.getElementById('next-btn').addEventListener('click', () => {
    currenttest = (currenttest + 1) % testimonials.length;
    showTestimonial(currenttest);
});
