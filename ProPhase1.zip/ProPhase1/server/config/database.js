const mongoose = require('mongoose')

const connectdatabase = async () => {
    try {
        mongoose.set('strictQuery', false);
        const conn = await mongoose.connect(process.env.MONGODB_URI);
        console.log(`Succesful database connction: ${conn.connection.host} `);
    }   catch (error) {
        console.log(error);
    }

}

module.exports = connectdatabase;