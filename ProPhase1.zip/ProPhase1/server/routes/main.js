const express = require('express');
const router = express.Router();
const Booking = require('../models/Booking');

// routes

router.get('/', (req, res) => {
    const locals = {
        title: "Yoga Workshop",
        description: "Yoga workshop, where you can book classes!"
    }

    res.render('home', locals);
});


router.get('/home', (req, res) => {
    const locals = {
        title: "Yoga Workshop",
        description: "Yoga workshop, where you can book classes!"
    }

    res.render('home', locals);
});


router.get('/about', (req, res) => {
    const locals = {
        title: "About",
        description: "About yoga for all!"
    }
    res.render('about', locals);
});

router.get('/help', (req, res) => {
    const locals = {
        title: "Help",
        description: "Help page"
    }
    res.render('help', locals);
});

router.get('/create_booking', (req, res) => {
    const locals = {
        title: "Book a class",
        description: "Page where you can book classes!"
    }
    res.render('create_booking', locals);
});


router.get('/bookings', async (req, res) => {
    const locals = {
        title: "Bookings",
        description: "Page to view all Bookings!"
    }
    try {
        const bookings = await Booking.find({});
        bookings.forEach(booking => {
            booking.formattedDate = booking.bookingDate.toDateString();
        });
        res.render('bookings', { bookings, locals });
    } catch (error) {
        console.error(`Error retrieving bookings: ${error.message}`);
        res.status(500).json({ message: 'Failed to retrieve bookings' });
    }
});


router.post('/bookings', async (req, res) => {
    try {
        const { name, email, phone, classType, skillLevel, date, time } = req.body;
        console.log('Received data:', req.body); 
        const booking = new Booking({
            name,
            email,
            number: phone,
            classType,
            skillLevel,
            bookingDate: date,
            bookingTime: time,
        });
        await booking.save();

        // redirect to the bookings page
        res.redirect('/bookings');
    } catch (error) {
        console.error(`Error creating booking: ${error.message}`);
        res.status(500).json({ message: 'Booking creation failed' });
    }
});

router.get('/delete_booking', (req, res) => {
    const locals = {
        title: "Delete a boooking!",
        description: "Page to delete all Bookings!"
    }
    res.render('delete_booking', locals);
});

router.get('/modify_booking', (req, res) => {
    const locals = {
        title: "Edit",
        description: "Page to edit a Booking!"
    }
    res.render('modify_booking', locals);
});

router.get('/report_booking', (req, res) => {
    const locals = {
        title: "Reports",
        description: "Page to report a Booking!"
    }
    res.render('report_booking', locals);
});

module.exports = router;    